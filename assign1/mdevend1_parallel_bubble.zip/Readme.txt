

How to run ?
./parallel_bubble N P

Note: Please dont include process more than 5 . As its causing hardware issues.

